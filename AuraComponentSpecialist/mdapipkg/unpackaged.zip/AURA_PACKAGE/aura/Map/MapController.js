({
    onPlotMapMarker: function (component,event,helper) { }   
})